package apigateWay.FlightBookingSystemAPI_Gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightBookingSystemApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
